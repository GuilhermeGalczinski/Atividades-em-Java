package verificacaoidade;

import java.util.Scanner;
import java.util.InputMismatchException;

public class VerificacaoIdade {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int idade = -1; // Inicializa com valor inválido
        boolean idadeValida = false;
        
        System.out.println("=== VERIFICACAO DE ACESSO POR IDADE ===");
        
        // Laço de repetição para garantir entrada válida
        while (!idadeValida) {
            try {
                System.out.print("Digite sua idade: ");
                idade = scanner.nextInt();
                
                // Validação se a idade é positiva
                if (idade < 0) {
                    System.out.println("Erro: A idade deve ser um numero positivo!");
                    System.out.println("Tente novamente.\n");
                } else if (idade == 0) {
                    System.out.println("Erro: A idade deve ser maior que zero!");
                    System.out.println("Tente novamente.\n");
                } else if (idade > 150) {
                    System.out.println("Erro: Idade muito alta! Digite uma idade valida.");
                    System.out.println("Tente novamente.\n");
                } else {
                    idadeValida = true; // Idade válida encontrada
                }
                
            } catch (InputMismatchException e) {
                System.out.println("Erro: Digite apenas números inteiros!");
                System.out.println("Tente novamente.\n");
                scanner.next(); // Limpa o buffer do scanner
            }
        }
        
        // Verificação de acesso baseada na idade
        System.out.println("\n--- RESULTADO DA VERIFICACAO ---");
        if (idade < 18) {
            System.out.println("Acesso negado");
            System.out.println("Motivo: Voce deve ter pelo menos 18 anos para acessar este conteudo.");
        } else {
            System.out.println("Acesso permitido");
            System.out.println("Bem-vindo! Voce pode acessar o conteúdo restrito.");
        }
        
        // Informação adicional sobre a idade
        if (idade >= 18 && idade < 65) {
            System.out.println("Categoria: Adulto");
        } else if (idade >= 65) {
            System.out.println("Categoria: Idoso - Você tem direito a benefícios especiais!");
        } else {
            System.out.println("Categoria: Menor de idade");
        }
        
        scanner.close();
    }
}