package calculadorasimples;

import java.util.Scanner;

public class CalculadoraSimples {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Entrada de dados
        System.out.print("Digite o primeiro numero inteiro: ");
        int numero1 = scanner.nextInt();
        
        System.out.print("Digite o segundo numero inteiro: ");
        int numero2 = scanner.nextInt();
        
        System.out.print("Digite a operacao (+, -, *, /): ");
        char operacao = scanner.next().charAt(0);
        
        // Variável para armazenar o resultado
        double resultado = 0;
        boolean operacaoValida = true;
        
        // Estrutura condicional para realizar a operação
        switch (operacao) {
            case '+':
                resultado = numero1 + numero2;
                System.out.printf("Resultado: %d + %d = %.2f%n", numero1, numero2, resultado);
                break;
                
            case '-':
                resultado = numero1 - numero2;
                System.out.printf("Resultado: %d - %d = %.2f%n", numero1, numero2, resultado);
                break;
                
            case '*':
                resultado = numero1 * numero2;
                System.out.printf("Resultado: %d * %d = %.2f%n", numero1, numero2, resultado);
                break;
                
            case '/':
                // Verificação para divisão por zero
                if (numero2 == 0) {
                    System.out.println("Erro: Divisão por zero não é permitida!");
                    operacaoValida = false;
                } else {
                    resultado = (double) numero1 / numero2;
                    System.out.printf("Resultado: %d / %d = %.2f%n", numero1, numero2, resultado);
                }
                break;
                
            default:
                System.out.println("Erro: Operação inválida! Use apenas +, -, * ou /");
                operacaoValida = false;
                break;
        }
        
        // Mensagem final (opcional)
        if (operacaoValida) {
            System.out.println("Calculação realizada com sucesso!");
        }
        
        scanner.close();
    }
}