package contagemregressiva;

import java.util.Scanner;
import java.util.InputMismatchException;

public class ContagemRegressiva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero = 0;
        boolean entradaValida = false;
        
        System.out.println("=== CONTAGEM REGRESSIVA ===");
        
        // Laço para garantir entrada válida
        while (!entradaValida) {
            try {
                System.out.print("Digite um numero inteiro positivo para a contagem: ");
                numero = scanner.nextInt();
                
                // Operadores lógicos para verificar se é negativo ou zero
                if (numero <= 0) {
                    System.out.println("Programa encerrado: Número deve ser positivo (maior que zero)!");
                    scanner.close();
                    return; // Para o programa imediatamente
                } else {
                    entradaValida = true;
                }
                
            } catch (InputMismatchException e) {
                System.out.println("Erro: Digite apenas números inteiros!");
                scanner.next(); // Limpa o buffer
            }
        }
        
        System.out.println("\n? Iniciando contagem regressiva...\n");
        
        // Pequena pausa antes de começar
        try {
            Thread.sleep(1000); // 1 segundo de pausa
        } catch (InterruptedException e) {
            // Ignora interrupção
        }
        
        // Laço de contagem regressiva usando for
        for (int i = numero; i > 0; i--) {
            System.out.println("Faltam " + i + " segundos");
            
            // Pausa de 1 segundo para simular contagem real
            try {
                Thread.sleep(1000); // 1000 milissegundos = 1 segundo
            } catch (InterruptedException e) {
                System.out.println("Contagem interrompida!");
                break;
            }
        }
        
        // Mensagem final quando chega ao zero
        System.out.println("\n? TEMPO ESGOTADO! ?");
        System.out.println("A contagem chegou ao fim!");
        
       
        scanner.close();
    }
}